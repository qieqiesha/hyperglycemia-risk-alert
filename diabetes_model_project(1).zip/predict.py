
import pandas as pd
import joblib
import sys

MODEL_PATH = "model.pkl"

def load_model():
    return joblib.load(MODEL_PATH)

def predict(input_csv):
    model = load_model()
    df = pd.read_csv(input_csv)
    preds = model.predict(df)
    probs = model.predict_proba(df)[:, 1]
    df["risk_pred"] = preds
    df["risk_score"] = probs
    return df

if __name__ == "__main__":
    input_file = sys.argv[1]
    result = predict(input_file)
    print(result.head())
