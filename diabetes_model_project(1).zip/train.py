
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
import joblib

# =========================
# Config
# =========================
DATA_PATH = "data.csv"   # replace with your dataset path
MODEL_PATH = "model.pkl"

# =========================
# Load data
# =========================
df = pd.read_csv(DATA_PATH)

# Expect target column: Diabetes_binary (0/1)
y = df["Diabetes_binary"]
X = df.drop(columns=["Diabetes_binary"])

# =========================
# Train/test split
# =========================
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

# =========================
# Model pipeline (small + fast)
# =========================
model = Pipeline([
    ("scaler", StandardScaler()),
    ("clf", LogisticRegression(max_iter=1000))
])

model.fit(X_train, y_train)

# =========================
# Save model (compact)
# =========================
joblib.dump(model, MODEL_PATH)

print("Model trained and saved to", MODEL_PATH)
