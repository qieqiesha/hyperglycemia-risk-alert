
# 高血糖风险预测模型说明

## 1. 模型目标
基于 BRFSS 2015 健康指标数据，构建二分类模型，用于预测个体是否存在高血糖/糖尿病风险。

## 2. 数据特征
常见输入特征包括：
- BMI（身体质量指数）
- 年龄
- 高血压史（HighBP）
- 高胆固醇（HighChol）
- 吸烟情况（Smoker）
- 身体活动（PhysActivity）
- 饮食习惯（Fruits / Veggies）
- 总体健康评分（GenHlth）
- 心理/身体健康状况（MentHlth / PhysHlth）
- 性别（Sex）

目标变量：
- Diabetes_binary（0=无风险，1=高风险）

## 3. 模型方法
使用：
- 标准化（StandardScaler）
- 逻辑回归分类模型（Logistic Regression）

优势：
- 模型体积极小（适合部署）
- 可解释性强
- 训练速度快

## 4. 输出结果
- risk_pred：分类结果（0/1）
- risk_score：风险概率（0~1）

## 5. 可扩展方向
- 可替换为 RandomForest / XGBoost 提升精度
- 可接入 SHAP 进行特征解释
- 可部署为 Web API（Flask/FastAPI）
